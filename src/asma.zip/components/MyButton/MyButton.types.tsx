export interface MyButtonProps {
  children: React.ReactNode;
  disabled?: boolean;
  backgroundColor?: string;
  visible?: boolean; // Add visible property
}
