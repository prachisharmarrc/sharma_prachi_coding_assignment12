export { default } from './MyButton';
