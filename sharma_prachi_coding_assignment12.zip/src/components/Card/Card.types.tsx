export interface CardProps {
    children: React.ReactNode;
    disabled?: boolean;
    visible?: boolean; // Add visible property
    backgroundColor?: string;
  }
  